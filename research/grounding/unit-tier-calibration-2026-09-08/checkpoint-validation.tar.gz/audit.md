# Unit tier audit

Scope: parked RuntimeMoth candidate, read-only audit under optimal-tests 2.6.0. Python 3.14.0, pytest; parser logic uses the pyramid shape, marker selection uses real pytest integration. No repository writes and no suite run.

## Verdict

No reproduced must-fix in the candidate. Integration should-fix: pyproject.toml:41 describes the marker as above five seconds, while the candidate threshold is 0.11. Reproduction: `rg -n 'above five seconds' pyproject.toml` exits 0.

## Branch map

| Decision | Best layer | Evidence |
| --- | --- | --- |
| Marked/unmarked collection | pytest integration | Existing pytester test checks selected and complete populations; not rerun |
| gzip/plain reports | parser unit plus disk artifact | Both executed |
| incomplete/nonpassing summary | parser unit plus real reports | Both rejected raw reports refused |
| duration node with spaces | parser unit | Candidate exact test passed |
| repeated phase | parser unit | Candidate exact test passed |
| missing phases/count mismatch | parser unit | Candidate exact tests passed |
| empty duration population | parser unit | Candidate synthetic test present; not rerun |
| duplicate resolved report path | parser unit | Candidate exact test passed |
| fewer than two observations | parser unit and artifact | Candidate exact test and artifact assertions passed |
| median strict threshold | parser unit and artifact | Candidate exact test and artifact assertions passed |
| omitted slow marker | artifact plus planted unit | Both candidate checks passed |
| largest threshold within budget | artifact | Candidate budget and next-threshold checks passed |

## Measurements

All recorded report hashes and sample-count assertions passed. Raw passing reports contain 2200 and 2156 nodes. Their union has 2200; 2156 have at least two samples, 44 have one. All 265 slow nodes are under tests/unit. Threshold 0.11 retains 1891 measured nodes totaling 54.775 seconds in summed medians; the next observed threshold 0.115 retains 56.270, above the 55-second budget. The one-sample nodes total 0.64 seconds in their single observation and are explicitly default-included.

Summed medians are a selection heuristic, not elapsed runtime. Accepted samples have differing populations, as permitted; failures are excluded, and the 44 one-sample nodes are explicit. Actual under-60 elapsed validation is owed after integration and is known to the coordinating agent. Full scripts/check.sh at line 133 uses unfiltered pytest.

## Triage

No fake boundary mocks, redundant cross-layer tests, or vacuous artifact assertions found. The pytester integration test exercises actual marker selection. The calibration test checks hashes, full sample-count mapping, exact slow-set equality, strict threshold, budget maximality, and a deliberately omitted slow node. No candidate source edits recommended from the executed evidence.

## Reproduction command for artifact arithmetic

```bash
UV_CACHE_DIR=/tmp/cairn-audit-uv-cache uv run --no-sync python -B - <<'PY'
import sys, types
from pathlib import Path
from statistics import median
p = Path('/tmp/cairn-runtimemoth.U7GUPL/tier-candidate')
m = types.ModuleType('_unit_tier')
m.__file__ = str(p / '_unit_tier.py')
s = (p / '_unit_tier.py').read_text().replace(
    'CALIBRATION_ROOT = Path(__file__).resolve().parents[1] / "research/grounding/unit-tier-calibration-2026-09-08"',
    f'CALIBRATION_ROOT = Path({str(p / "evidence")!r})',
)
exec(compile(s, m.__file__, 'exec'), m.__dict__)
sys.modules['_unit_tier'] = m
ns = {'__file__': str(p / 'test_check_unit_tier.py')}
exec(compile((p / 'test_check_unit_tier.py').read_text(), ns['__file__'], 'exec'), ns)
ns['test_recorded_unit_durations_have_no_unmarked_slow_tests']()
samples = m.unit_duration_samples([p / 'evidence' / r['path'] for r in m.CALIBRATION['reports']])
med = {n: median(v) for n, v in samples.items() if len(v) >= 2}
nxt = min(v for v in med.values() if v > m.SLOW_SECONDS)
assert all(n.startswith('tests/unit/') for n in m.SLOW_UNIT_TESTS)
print('artifact assertions PASS')
print('counts', len(samples), len(med), len(m.SLOW_UNIT_TESTS), len(m.CALIBRATION['unmeasured_nodeids']))
print('next threshold', nxt, 'retained sum', sum(v for v in med.values() if v <= nxt))
print('unmeasured sum', sum(v[0] for v in samples.values() if len(v) < 2))
PY
```

Raw observed output, exit 0:

```text
artifact assertions PASS
counts 2200 2156 265 44
next threshold 0.115 retained sum 56.270
unmeasured sum 0.64
```
