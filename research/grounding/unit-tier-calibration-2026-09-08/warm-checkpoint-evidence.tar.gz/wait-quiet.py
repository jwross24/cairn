import pathlib, subprocess, time
root=pathlib.Path('/tmp/cairn-runtimemoth.U7GUPL')
while True:
    result=subprocess.run(['pgrep','-fl','pytest'],capture_output=True,text=True)
    (root/'quiet-process-current.log').write_text(result.stdout+result.stderr)
    if result.returncode == 1:
        print('QUIET: starting captured reports',flush=True)
        raise SystemExit(subprocess.run(['uv','run','--no-sync','python',str(root/'collect-tier.py')]).returncode)
    if result.returncode != 0:
        raise RuntimeError(result.stderr)
    print('WAIT: competing processes remain',flush=True)
    time.sleep(30)
