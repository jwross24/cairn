# Fresh warm-hook audit

Fresh read-only agent warm_hook_audit used gpt-6-astra, the available Codex model authorized by CopperRidge. No agent pytest, build, provider, container or source-write calls. Its imported-module collision claim was initially unverified because its uv cache access failed. Root supplied exit-0 evidence before the fix.

Root's importer probe installed a sentinel test_br_lookup module with a different __file__, then called installed pytest's import_path in importlib mode against the real file. It returned the sentinel, exit0. The occurrence reproduction ran the real test_br_lookup.py with the positive warm-hook test: inner pytest executed12 real tests rather than the expected1, so outer pytest exited1. The wrapper asserted this failure and exited0. Raw: warm-mixed-repro-w3c7h40e/raw.log.

Synthetic consumers live under warm_cases/test_br_lookup.py. The positive test imports real test_br_lookup before the nested run, retaining the collision premise even in isolation. Mixed real-module plus whole tier-test-file validation:32passed26.89s, exit0. Final named file:20passed6.72s, exit0. Numeric elapsed logging is asserted. Raw: warm-mixed-fixed-x26vrnh2/raw.log and warm-final-tests-mtf0rmxc/raw.log.

The audit noted that the positive test permits a cache hit and therefore does not prove cold construction independently. The separate real cold/cache probe provides that evidence:16.569622540999262s cold and0.0000053340045269578695s cached, same workspace, one miss and one hit, exit0. No claim of controlled attribution of the earlier15.75s test.

Consumer inventory checks direct from-imports under tests and excludes conftest itself, which is the warming hook. The failure test exercises a callable error; an import failure is not separately planted. Collection-finish is outside per-item duration calls; root independently read installed pytest runner.py123-134/236-255, python.py1709-1710 and main.py868-879. Session fixtures would remain in the first setup duration. Total pytest/command wall still includes warm time.
