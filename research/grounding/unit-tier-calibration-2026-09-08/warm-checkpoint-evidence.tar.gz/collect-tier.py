import json
import pathlib
import subprocess
import tempfile
import time

root = pathlib.Path(tempfile.mkdtemp(prefix='unit-load-captured-', dir='/tmp/cairn-runtimemoth.U7GUPL'))
print(root, flush=True)
for index in (1, 2, 3):
    captures = {}
    for name, command in [('processes', ['pgrep', '-fl', 'pytest']), ('uptime', ['uptime'])]:
        result = subprocess.run(command, capture_output=True, text=True)
        captures[f'before_{name}'] = dict(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    (root / f'run-{index}-before.json').write_text(json.dumps(captures, indent=2)+'\n')
    if captures['before_processes']['returncode'] not in (0, 1):
        raise RuntimeError(captures)
    if captures['before_processes']['returncode'] == 0:
        print('BLOCKED: competing pytest before run', flush=True)
        break
    command = ['uv', 'run', '--no-sync', 'pytest', 'tests/unit', '-q', '--durations=0', '--durations-min=0', f'--basetemp={root / f"pytest-{index}"}']
    start = time.monotonic()
    with (root / f'run-{index}.log').open('w') as out:
        process = subprocess.Popen(command, stdout=out, stderr=subprocess.STDOUT)
        during = []
        while process.poll() is None:
            capture = subprocess.run(['pgrep', '-fl', 'pytest'], capture_output=True, text=True)
            others = [line for line in capture.stdout.splitlines() if str(root) not in line]
            during.append(dict(elapsed_seconds=time.monotonic()-start, returncode=capture.returncode, stdout=capture.stdout, stderr=capture.stderr, competing=others))
            (root / f'run-{index}-during.json').write_text(json.dumps(during, indent=2)+'\n')
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pass
        returncode = process.wait()
    evidence = dict(command=command, elapsed_seconds=time.monotonic()-start, returncode=returncode)
    for name, command in [('processes', ['pgrep', '-fl', 'pytest']), ('uptime', ['uptime'])]:
        capture = subprocess.run(command, capture_output=True, text=True)
        captures[f'after_{name}'] = dict(returncode=capture.returncode, stdout=capture.stdout, stderr=capture.stderr)
    evidence['captures'] = captures
    evidence['uncontended_endpoints'] = all(captures[f'{point}_processes']['returncode'] == 1 for point in ('before', 'after'))
    evidence['uncontended_samples'] = evidence['uncontended_endpoints'] and all(not item['competing'] and item['returncode'] in (0, 1) for item in during)
    (root / f'run-{index}.json').write_text(json.dumps(evidence, indent=2)+'\n')
    print(json.dumps(evidence), flush=True)
    accepted = [json.loads(path.read_text()) for path in root.glob('run-[0-9].json')]
    if sum(item['returncode'] == 0 and item['uncontended_samples'] for item in accepted) >= 2:
        break
