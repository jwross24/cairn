import ast
import errno
import os
import tempfile
from pathlib import Path

import pytest

source = Path("tests/conftest.py").read_text()
node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == "_snapshot")
guarded = ast.get_source_segment(source, node)
block = "try:\n                is_file = entry.is_file()\n            except (OSError, ValueError):\n                is_file = False\n            if is_file:\n                st = entry.stat()"
block = block if block in guarded else block.replace("except (OSError, ValueError):", "except OSError, ValueError:")
assert guarded.count(block) == 1
original = guarded.replace(block, "path = Path(entry.path)\n            if path.is_file():\n                st = path.stat()")
raw = guarded.replace(block, "if entry.is_file():\n                st = entry.stat()")
permission_only = guarded.replace(block, block.replace("except (OSError, ValueError):", "except PermissionError:").replace("except OSError, ValueError:", "except PermissionError:"))
suite = Path("tests/unit/test_isolation_snapshot.py").read_text()
node = next(n for n in ast.parse(suite).body if isinstance(n, ast.FunctionDef) and n.name == "test_snapshot_ignores_inaccessible_and_cyclic_file_links")
namespace = {"pytest": pytest}
exec(ast.get_source_segment(suite, node), namespace)
check = namespace[node.name]
for label, candidate, expected_errno in [("original", original, None), ("guarded", guarded, None), ("raw", raw, errno.EACCES), ("permission_only", permission_only, errno.ELOOP)]:
    env = {"os": os, "Path": Path, "GUARDED_DIRS": (".doctor", "deploy", "var")}
    exec(candidate, env)
    scratch = Path(tempfile.mkdtemp(prefix="cairn-link-audit-"))
    try:
        check(scratch, env["_snapshot"])
    except OSError as exc:
        assert expected_errno is not None and exc.errno == expected_errno, (label, exc)
        print(label, "REJECTED", type(exc).__name__, exc.errno)
    else:
        assert expected_errno is None, (label, "mutant survived")
        print(label, "PASS")
    assert (scratch / "hidden").stat().st_mode & 0o777 == 0o700
    print("retained", scratch)
