import json
import os
import runpy
import statistics
import time
from pathlib import Path

scope = runpy.run_path(str(Path(__file__).with_name("snapshot-before-conftest.py")))
original = scope["_snapshot"]
root = Path.cwd()


def candidate(root):
    seen = {}
    pending = []
    for name in scope["GUARDED_DIRS"]:
        base = root / name
        if base.exists():
            pending.append((base, name))
    while pending:
        directory, relative = pending.pop()
        try:
            with os.scandir(directory) as entries:
                children = list(entries)
        except OSError:
            continue
        for entry in children:
            name = relative + "/" + entry.name
            try:
                is_file = entry.is_file()
            except (OSError, ValueError):
                is_file = False
            if is_file:
                st = entry.stat()
                seen[name] = (st.st_size, st.st_mtime_ns)
            else:
                try:
                    is_directory = entry.is_dir(follow_symlinks=False)
                except OSError:
                    is_directory = False
                if is_directory:
                    pending.append((entry.path, name))
    return seen


expected = original(root)
assert candidate(root) == expected
rows = []
for pair in range(20):
    order = [("original", original), ("candidate", candidate)]
    if pair % 2:
        order.reverse()
    for label, function in order:
        started = time.perf_counter()
        cpu_started = time.process_time()
        for _ in range(30):
            assert function(root) == expected
        rows.append(
            {
                "pair": pair,
                "label": label,
                "calls": 30,
                "wall_seconds": time.perf_counter() - started,
                "cpu_seconds": time.process_time() - cpu_started,
            }
        )
Path("/tmp/cairn-runtimemoth.U7GUPL/direntry-cost.json").write_text(
    json.dumps({"files": len(expected), "rows": rows}, indent=2) + "\n"
)
for label in ("original", "candidate"):
    selected = [row for row in rows if row["label"] == label]
    print(label, {key: statistics.median(row[key] / 30 for row in selected) for key in ("wall_seconds", "cpu_seconds")})
