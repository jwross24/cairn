The accepted checkpoint claim follows CopperRidge message 694: median paired CPU
saving is 2.630 milliseconds per snapshot, projecting to 5.507 seconds across 2094
snapshots. The paired wall projection of 76.498 seconds is a host-contention-sensitive
observation, not the optimization claim. CopperRidge reported load average 87 during
this work; the measurement does not capture per-sample load averages. Message 694
approves this CPU-sized checkpoint despite the earlier ten-second criterion.

The fast gate passes. Main-session audit re-execution exits zero with raw output:

```text
original PASS
guarded PASS
raw REJECTED PermissionError 13
permission_only REJECTED OSError 62
```

The probe executes the exact focused test against four in-memory function variants
and verifies permission restoration. It changes no repository source.

Mechanism verified, occurrence not observed: DirEntry caches a symlink target's
metadata between is_file() and stat() during one traversal; CopperRidge message 684
accepts this bounded narrowing. No identical metadata-read semantics, production
race, CI speedup, passing full suite, sixty-second unit tier, or close is claimed.
