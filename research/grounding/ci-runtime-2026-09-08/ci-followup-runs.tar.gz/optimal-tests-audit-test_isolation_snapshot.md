# Snapshot close audit

Confidence: HIGH for the direct probes and source inspection. No concrete test blocker for closing cairn-1s2 as a measured investigation result was established. No full-branch-coverage or identical-metadata-semantics claim is supported.

## Phase 0

Python 3.14, pytest. Filesystem boundary helper: real-filesystem component tests are the useful layer. The file resides under unit but uses real OS operations and no mocks. Seven parameter-expanded cases run by direct invocation of the exact test functions; this is not pytest fixture dispatch or a full gate.

## Phase 1

| Source | Decision | Best layer | Evidence |
|---|---|---|---|
| 34-37 | Guarded roots present/absent | Real filesystem component | Covered, including all three root names, symlink roots and a file root |
| 38-45 | Pending traversal; scandir success/OSError | Real filesystem component | Covered by nested files, empty roots, unreadable directory and file root |
| 48-50 | is_file success/OSError/ValueError | Real filesystem component | True/false and EACCES/ELOOP covered; ValueError unexercised |
| 51-53 | Record file metadata | Real filesystem component | Covered by exact size/mtime tuples and file symlink target; subsequent change detected |
| 55-60 | Non-following is_dir true/false/OSError | Real filesystem component | True/false covered, including directory links, FIFO, broken link and cycles; OSError handler lines 57-58 unexercised |

The unexercised exception arms are coverage limits, not demonstrated reachable defects. No new mandatory tests are prescribed for hypothetical races. Within-pass DirEntry symlink metadata caching is the expressly accepted bounded narrowing, with occurrence unobserved per CP684/694.

## Phase 2

| Test | Layer | Triage | Action |
|---|---|---|---|
| tracks_files_without_following_directory_links | Real filesystem component | Exact nonempty mapping, root alias normalization, exclusions, mutation detection | Keep |
| follows_a_guarded_root_link | Real filesystem component | Three output prefixes differ; parameterization checks each guarded root | Keep |
| of_missing_roots_is_empty | Real filesystem component | Deliberately empty root cases with producer understood | Keep |
| ignores_unreadable_subdirectories | Real filesystem component | OS denial is asserted before snapshot; permissions restored in finally | Keep |
| ignores_inaccessible_and_cyclic_file_links | Real filesystem component | Actual EACCES and ELOOP; exact snapshot output; both faulty variants rejected | Keep |

No mocks, no fixture-induced vacuity, no contradictory docstring, no established redundant boundary test. Bare PermissionError assertions here establish OS preconditions, not application exception-message promises. Optional stylistic changes do not block this investigation close.

## Exact commands

```bash
UV_CACHE_DIR=/tmp/cairn-runtime-close-uv PYTHONDONTWRITEBYTECODE=1 uv run --no-sync python /tmp/optimal-tests-audit-snapshot-close.nKibuC/probe.py
UV_CACHE_DIR=/tmp/cairn-runtime-close-uv PYTHONDONTWRITEBYTECODE=1 uv run --no-sync python /tmp/cairn-runtimemoth.U7GUPL/direntry-audit.py
```

Both commands exited 0. The first passed seven exact real-filesystem cases. Source execution reached all snapshot statements except lines 57-58. The second reported original PASS, guarded PASS, raw REJECTED PermissionError 13, permission_only REJECTED OSError 62. Temporary fixtures are retained; no repository source was modified.

## Close scope

The bead acceptance explicitly allows a measured no-optimization conclusion. The accepted small CPU checkpoint does not establish a causal CI speedup. The recorded CI result on 313d145 is 3448 passed, 5 skipped, 1 xfailed in 985.21 seconds; this audit did not rerun or independently fetch CI. Skips are not passes. The under-60-second unit tier remains unmet and is outside this investigation's close claim. Main must check the artifact/raw-output, timing-margin, and closing-gate requirements separately.
