Fresh read-only optimal-tests audit: no concrete snapshot-test blocker for this
investigation close. Main reexecuted both cited probes, exit 0, with raw output:

original PASS
guarded PASS
raw REJECTED PermissionError 13
permission_only REJECTED OSError 62
7 exact real-filesystem test cases passed; no source mutation, no fixture dispatch

The audit leaves is_dir OSError and is_file ValueError alternatives unexercised;
no reachable defect is demonstrated. Mac/Linux permission premises remain the
open cairn-hcl parity work's responsibility, not a universal-platform claim.

Close commands and raw results:
scripts/check.sh --fast
[check] all gates pass
scripts/bead-artifact-block.sh cairn-1s2
[artifact-block] pass cairn-1s2 (in_progress): 2 source, 1 test, 2 commit, 3 command
scripts/bead-test-plan.sh cairn-1s2
[test-plan] pass cairn-1s2 (in_progress): every named test file exists, and every test module collects
uv run pytest -q tests/unit/test_isolation_snapshot.py --basetemp=/tmp/cairn-runtimemoth.U7GUPL/close-snapshot-clean
7 passed in 0.14s

The initial default-temp run reports 7 passed, 1876 warnings in 1.93s from stale
pytest cleanup permission errors. The fresh-basetemp run avoids that shared cleanup
state; it does not fix or delete those directories. Both raw logs are archived.

No-Claim: no all-branches-covered result, full local suite, under-sixty-second tier,
causal CI speedup, identical within-pass metadata semantics, or mathematical claim.
