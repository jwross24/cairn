Existing unit profile: 2092 passed, 2 failed, 2 deselected; 750.37s pytest, not a passing baseline. Two failures are C1 in-flight human_queue edits. No additional suite run. Official call total: 475.098548s.

Top 25 call phases:
28.887340s tests/unit/test_justify_properties.py::test_mr_w_widening_further_keeps_the_same_class [passed]
24.366180s tests/unit/test_justify_properties.py::test_mr_w_moving_an_endpoint_inside_the_scope_is_a_coverage_violation [passed]
22.504574s tests/unit/test_justify_properties.py::test_mr_an_audit_only_grade_justifies_nothing_whatever_the_evidence [passed]
21.495969s tests/unit/test_justify_properties.py::test_every_named_mutant_is_killed_by_its_relation[derive_takes_last_node] [passed]
15.488598s tests/unit/test_runner_fuzz.py::test_a_malformed_document_always_maps_to_fail [passed]
15.025943s tests/unit/test_justify_properties.py::test_every_named_mutant_is_killed_by_its_relation[kind_table_off_by_one] [passed]
14.444989s tests/unit/test_runner_fuzz.py::test_the_parser_never_raises_and_the_receipt_is_never_trusted [passed]
14.191861s tests/unit/test_substrate_predicates.py::test_output_manifest_hash_is_order_and_hex_bytes_invariant [passed]
12.280910s tests/unit/test_justify_properties.py::test_mr_c_no_result_ever_exceeds_the_kind_ceiling [passed]
11.353843s tests/unit/test_justify_properties.py::test_every_named_mutant_is_killed_by_its_relation[producer_rule_ignores_range] [passed]
11.266400s tests/unit/test_selftest_corpus_fuzz.py::test_arbitrary_json_is_refused_typed_or_accepted_never_unhandled [passed]
10.503812s tests/unit/test_selftest_corpus_fuzz.py::test_every_corpus_mutation_is_refused_with_a_path_before_any_pari_call [passed]
9.481628s tests/unit/test_justify_properties.py::test_mr_a_an_assumption_outside_the_scope_is_always_a_coverage_violation [passed]
9.344487s tests/unit/test_justify_properties.py::test_mr_m_the_derived_class_never_exceeds_the_strongest_kind_ceiling [passed]
9.245587s tests/unit/test_justify_properties.py::test_every_named_mutant_is_killed_by_its_relation[comparator_strict_containment] [passed]
9.130826s tests/unit/test_justify_properties.py::test_mr_c_a_producer_with_no_covering_basis_caps_at_conjecture [passed]
8.868034s tests/unit/test_cli_contract.py::test_json_commands_emit_exactly_one_document_on_stdout[m0-run] [passed]
8.796071s tests/unit/test_claims_properties.py::test_two_statements_differing_in_exactly_one_typed_field_hash_differently [passed]
8.787578s tests/unit/test_justify_properties.py::test_every_named_mutant_is_killed_by_its_relation[comparator_assumptions_superset] [passed]
8.424899s tests/unit/test_cli_contract.py::test_json_commands_emit_exactly_one_document_on_stdout[selftest] [passed]
8.346359s tests/unit/test_verifier_fuzz.py::test_run_fields_never_spawns_on_a_refusal_and_never_raises [passed]
7.885113s tests/unit/test_justify_properties.py::test_mr_m_the_derived_class_never_falls_as_nodes_are_appended [passed]
7.494253s tests/unit/test_runner_fuzz.py::test_the_status_is_always_one_of_the_five [passed]
6.126118s tests/unit/test_gateplan_fuzz.py::test_validating_a_plan_spawns_no_subprocess_and_writes_no_gate_runs_row [passed]
5.882751s tests/unit/test_tier_gate_properties.py::test_reasons_are_a_subsequence_of_the_fixed_order [passed]

All call phases grouped by module, largest 15:
212.280482s tests/unit/test_justify_properties.py
37.440332s tests/unit/test_runner_fuzz.py
21.859286s tests/unit/test_selftest_corpus_fuzz.py
21.533740s tests/unit/test_cli_contract.py
19.388862s tests/unit/test_tier_gate_properties.py
18.559533s tests/unit/test_attest_fuzz.py
18.263900s tests/unit/test_verifier_fuzz.py
14.205749s tests/unit/test_substrate_predicates.py
13.345084s tests/unit/test_canon_properties.py
12.244932s tests/unit/test_theater_patterns.py
11.530047s tests/unit/test_gateplan_fuzz.py
11.433908s tests/unit/test_claims_properties.py
7.041562s tests/unit/test_libpari_stall_hook.py
6.972378s tests/unit/test_pari_module.py
6.812367s tests/unit/test_gc_properties.py

No-Claim: no passing baseline, irreducible floor, expected optimization gain from whole-test duration, or changed examples/markers/deadlines.
