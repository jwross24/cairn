import ast
import os
import sys
import tempfile
from pathlib import Path

import pytest

source = Path('tests/conftest.py').read_text()
node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == '_snapshot')
env = {'os': os, 'GUARDED_DIRS': ('.doctor', 'deploy', 'var')}
exec(compile(ast.Module(body=[node], type_ignores=[]), 'snapshot-audit', 'exec'), env)
suite = {'os': os, 'pytest': pytest}
exec(compile(Path('tests/unit/test_isolation_snapshot.py').read_text(), 'snapshot-tests-audit', 'exec'), suite)
lines = set()


def trace(frame, event, arg):
    if frame.f_code.co_filename == 'snapshot-audit' and event == 'line':
        lines.add(frame.f_lineno)
    return trace


count = 0
for name, check in suite.items():
    if not name.startswith('test_'):
        continue
    cases = ('.doctor', 'deploy', 'var') if name == 'test_snapshot_follows_a_guarded_root_link' else (None,)
    for case in cases:
        scratch = Path(tempfile.mkdtemp(prefix='cairn-snapshot-close-audit-'))
        kwargs = {'tmp_path': scratch, 'isolation_snapshot': env['_snapshot']}
        if case is not None:
            kwargs['name'] = case
        sys.settrace(trace)
        try:
            check(**kwargs)
        finally:
            sys.settrace(None)
        count += 1
        print('PASS', name, case)
assert count == 7
print('executed source lines', sorted(lines))
print('7 exact real-filesystem test cases passed; no source mutation, no fixture dispatch')
