import copy
import json
import runpy
import statistics
import time

from cairn import selftest

factories = runpy.run_path('tests/factories.py')
assumption_id = factories['assumption_id']
names = factories['ASSUMPTION_NAMES']
digests = {name: assumption_id(name) for name in names}
raw = selftest.CORPUS_PATH.read_text()
base = json.loads(raw)


def typed(value):
    if isinstance(value, dict):
        return (dict, tuple((key, typed(item)) for key, item in value.items()))
    if isinstance(value, list):
        return (list, tuple(typed(item) for item in value))
    return (type(value), value)


assert typed(copy.deepcopy(base)) == typed(json.loads(raw))
first = json.loads(raw)
second = json.loads(raw)
first['cases'][0]['id'] = 'independence-probe'
assert second == base
assert all(assumption_id(name) == digests[name] for name in names)

rows = []
for candidate, original, replacement in (
    ('corpus_copy', lambda: copy.deepcopy(base), lambda: json.loads(raw)),
    ('six_assumptions', lambda: tuple(assumption_id(name) for name in names), lambda: tuple(digests[name] for name in names)),
):
    for pair in range(20):
        order = [('original', original), ('candidate', replacement)]
        if pair % 2:
            order.reverse()
        for label, fn in order:
            wall = time.perf_counter()
            cpu = time.process_time()
            for _ in range(500):
                fn()
            rows.append({'candidate': candidate, 'pair': pair, 'label': label, 'calls': 500, 'cpu': time.process_time() - cpu, 'wall': time.perf_counter() - wall})
    for field in ('cpu', 'wall'):
        selected = [row for row in rows if row['candidate'] == candidate]
        medians = {label: statistics.median(row[field] for row in selected if row['label'] == label) for label in ('original', 'candidate')}
        differences = []
        for pair in range(20):
            values = {row['label']: row[field] for row in selected if row['pair'] == pair}
            differences.append(values['original'] - values['candidate'])
        print(candidate, field, medians, 'paired_saving', statistics.median(differences), flush=True)
print('PASS: typed ordered equality, independent corpus mutation, identical assumption digests', flush=True)
print(json.dumps(rows))
