import json
import logging
import runpy
import statistics
import tempfile
import time
from pathlib import Path

baseline = runpy.run_path("tests/conftest.py")["_JsonLineHandler"]
root = Path(tempfile.mkdtemp(prefix="cairn-log-cost-"))


class PersistentHandler(logging.Handler):
    def __init__(self, path):
        super().__init__(level=logging.DEBUG)
        self.path = path
        self.stream = None

    def emit(self, record):
        data = {
            "ts": record.created,
            "level": record.levelname,
            "step": getattr(record, "step", None),
            "event": record.getMessage(),
        }
        data.update(getattr(record, "fields", {}) or {})
        if self.stream is None:
            self.stream = self.path.open("a")
        self.stream.write(json.dumps(data, sort_keys=True, default=str) + "\n")
        self.stream.flush()

    def close(self):
        try:
            if self.stream is not None:
                self.stream.close()
                self.stream = None
        finally:
            super().close()


records = []
for index in range(1052):
    record = logging.LogRecord("cairn", logging.INFO, __file__, 0, "event %s", (index,), None)
    record.created = 1234567890.0
    record.step = "measurement"
    record.fields = {"index": index, "payload": "test record"}
    records.append(record)
rows = []
for pair in range(20):
    order = [("original", baseline), ("candidate", PersistentHandler)]
    if pair % 2:
        order.reverse()
    paths = {}
    for label, handler_type in order:
        path = root / f"{pair}-{label}.jsonl"
        handler = handler_type(path)
        started = time.perf_counter()
        cpu_started = time.process_time()
        try:
            for record in records:
                handler.emit(record)
        finally:
            handler.close()
        rows.append({"pair": pair, "label": label, "records": len(records), "wall_seconds": time.perf_counter() - started, "cpu_seconds": time.process_time() - cpu_started})
        paths[label] = path
    assert paths["original"].read_bytes() == paths["candidate"].read_bytes()
for label, handler_type in [("original", baseline), ("candidate", PersistentHandler)]:
    path = root / f"visibility-{label}.jsonl"
    path.write_text("existing\n")
    handler = handler_type(path)
    try:
        for index, record in enumerate(records[:3], start=1):
            handler.emit(record)
            lines = path.read_text().splitlines()
            assert lines[0] == "existing" and len(lines) == index + 1
    finally:
        handler.close()
Path("/tmp/cairn-runtimemoth.U7GUPL/log-handler-cost.json").write_text(json.dumps({"scratch": str(root), "rows": rows}, indent=2) + "\n")
for field in ("wall_seconds", "cpu_seconds"):
    medians = {label: statistics.median(row[field] for row in rows if row["label"] == label) for label in ("original", "candidate")}
    differences = []
    for pair in range(20):
        values = {row["label"]: row[field] for row in rows if row["pair"] == pair}
        differences.append(values["original"] - values["candidate"])
    print(field, medians, "paired_saving", statistics.median(differences))
print("PASS: 20 equal byte streams; per-record visibility and append checks; scratch retained", root)
