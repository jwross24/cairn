import gzip
import json
import os
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def capture(argv):
    result = subprocess.run(argv, capture_output=True, text=True)
    return {"argv": argv, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


fingerprint = {
    "captured_at": datetime.now(timezone.utc).isoformat(),
    "source": capture(["git", "rev-parse", "HEAD"]),
    "status": capture(["git", "status", "--short"]),
    "python": sys.version,
    "kernel": platform.release(),
    "machine": platform.machine(),
    "logical_cpu_count": os.cpu_count(),
    "cpu_model": capture(["sysctl", "-n", "machdep.cpu.brand_string"]),
    "physical_cores": capture(["sysctl", "-n", "hw.physicalcpu"]),
    "memory_bytes": capture(["sysctl", "-n", "hw.memsize"]),
    "swap": capture(["sysctl", "vm.swapusage"]),
    "filesystem": capture(["df", "-P", "."]),
    "power_configuration": capture(["pmset", "-g", "custom"]),
    "isolation": "shared host; no affinity or OS tuning; serial commands",
    "cache": "warm after first invocation",
}
(ROOT / "fingerprint.json").write_text(json.dumps(fingerprint, indent=2) + "\n")
commands = {
    "collection": ["uv", "run", "pytest", "tests/unit", "--collect-only", "-q"],
    "bare_import": ["uv", "run", "python", "-c", "import cairn"],
}
rows = []
for label, command in commands.items():
    for index in range(20):
        started = time.perf_counter()
        result = subprocess.run(["/usr/bin/time", "-l", *command], capture_output=True)
        elapsed = time.perf_counter() - started
        (ROOT / f"{label}-{index:02d}.stdout.gz").write_bytes(gzip.compress(result.stdout, mtime=0))
        (ROOT / f"{label}-{index:02d}.stderr.gz").write_bytes(gzip.compress(result.stderr, mtime=0))
        rows.append(
            {
                "scenario": label,
                "sample": index,
                "argv": command,
                "wall_seconds": elapsed,
                "exit_code": result.returncode,
                "stdout_bytes": len(result.stdout),
            }
        )
        (ROOT / "baseline.json").write_text(json.dumps(rows, indent=2) + "\n")
        if result.returncode:
            print(label, index, result.returncode, flush=True)
            raise SystemExit(result.returncode)
    print(label, "20 passing samples", flush=True)
