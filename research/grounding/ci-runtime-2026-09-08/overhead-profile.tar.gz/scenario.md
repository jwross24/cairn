# Unit collection and fixture attribution

Source: current Cairn main, with exact commit and host recorded in fingerprint.json.
Question: how much of the unit gate belongs to collection, imports, fixture setup/teardown, and test call phases?
Success: attribute observed phase time without altering test membership, sample counts, deadlines, or epistemic gates.
Budget: the unit gate target remains sixty seconds. The top-ten duration remainder is not assumed to be overhead.
Output: complete passing collection, unchanged collected node ids, raw timing/import/setup reports, and a ranked cost report with uncertainty.
Baseline: twenty collection-only invocations and twenty bare-package imports, serially, warm filesystem cache after the first invocation. No full local suite.
Environment: shared macOS host, no OS tuning, no CPU affinity, no other pytest process observed before the batch. Fingerprint fields distinguish unavailable values from measured values.
Profileability: ordinary Python interpreter; no optimized binary rebuild or stripping applies. Import timing and optional pytest timing hooks are measurement-only and do not alter test code.
Limits: collection baselines do not provide twenty full-unit latency samples. One later phase-attribution run is not a stable whole-suite performance baseline. Tail estimates from twenty samples are conservative and are not population tail guarantees.
