import json
import os
import tempfile
from pathlib import Path

root = Path(tempfile.mkdtemp(prefix="cairn-direntry-probe-"))
target = root / "target"
target.write_text("a")
link = root / "link"
link.symlink_to(target)
with os.scandir(root) as entries:
    entry = next(item for item in entries if item.name == "link")
    assert entry.is_file()
    target.write_text("longer")
    cached = entry.stat().st_size
    fresh = Path(entry.path).stat().st_size
    assert cached == 1 and fresh == 6
    print(json.dumps({"DirEntry.stat_size": cached, "Path.stat_size": fresh}))
