import json
import os
import resource
import time
from contextlib import contextmanager
from pathlib import Path

import pytest

OUTPUT = Path(os.environ["RUNTIMEMOTH_PROFILE_OUT"])
IMPORTED = time.perf_counter()
PHASES = []
FIXTURES = []
REPORTS = []
SESSION = {}


@contextmanager
def timed_phase(nodeid, phase):
    started = time.perf_counter()
    cpu_started = time.process_time()
    children_started = resource.getrusage(resource.RUSAGE_CHILDREN)
    try:
        yield
    finally:
        children = resource.getrusage(resource.RUSAGE_CHILDREN)
        PHASES.append(
            {
                "nodeid": nodeid,
                "phase": phase,
                "wall_seconds": time.perf_counter() - started,
                "self_cpu_seconds": time.process_time() - cpu_started,
                "child_cpu_seconds": children.ru_utime
                + children.ru_stime
                - children_started.ru_utime
                - children_started.ru_stime,
            }
        )


def pytest_configure(config):
    if OUTPUT.exists():
        raise RuntimeError(f"profiling output already exists: {OUTPUT}")


def pytest_sessionstart(session):
    SESSION["started"] = time.perf_counter()
    SESSION["cpu_started"] = time.process_time()


@pytest.hookimpl(wrapper=True)
def pytest_collection(session):
    with timed_phase("", "collection"):
        return (yield)


@pytest.hookimpl(wrapper=True)
def pytest_runtest_setup(item):
    with timed_phase(item.nodeid, "setup"):
        return (yield)


@pytest.hookimpl(wrapper=True)
def pytest_runtest_call(item):
    with timed_phase(item.nodeid, "call"):
        return (yield)


@pytest.hookimpl(wrapper=True)
def pytest_runtest_teardown(item, nextitem):
    with timed_phase(item.nodeid, "teardown"):
        return (yield)


@pytest.hookimpl(wrapper=True)
def pytest_fixture_setup(fixturedef, request):
    started = time.perf_counter()
    try:
        return (yield)
    finally:
        FIXTURES.append(
            {
                "name": fixturedef.argname,
                "scope": fixturedef.scope,
                "nodeid": request.node.nodeid,
                "started": started,
                "finished": time.perf_counter(),
            }
        )


def pytest_runtest_logreport(report):
    REPORTS.append(
        {
            "nodeid": report.nodeid,
            "phase": report.when,
            "duration": report.duration,
            "outcome": report.outcome,
        }
    )


def pytest_sessionfinish(session, exitstatus):
    OUTPUT.write_text(
        json.dumps(
            {
                "exitstatus": int(exitstatus),
                "pytest_version": pytest.__version__,
                "pre_session_seconds": SESSION["started"] - IMPORTED,
                "session_wall_seconds": time.perf_counter() - SESSION["started"],
                "session_self_cpu_seconds": time.process_time() - SESSION["cpu_started"],
                "self_rusage": list(resource.getrusage(resource.RUSAGE_SELF)),
                "phases": PHASES,
                "fixtures": FIXTURES,
                "reports": REPORTS,
            },
            indent=2,
        )
        + "\n"
    )
