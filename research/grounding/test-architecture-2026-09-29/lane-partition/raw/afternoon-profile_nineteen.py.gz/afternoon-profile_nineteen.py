import copy
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
pin = "9f68240ae5bf7f3c060d2560e6df7f86a06721ed"
source = subprocess.check_output(["git", "show", f"{pin}:research/grounding/test-architecture-2026-09-29/pilot_profile.py"])
extractor_path = root / "pinned_pilot_profile.py"
extractor_path.write_bytes(source)
spec = importlib.util.spec_from_file_location("pinned_profile", extractor_path)
profile = importlib.util.module_from_spec(spec)
spec.loader.exec_module(profile)
manifest = {"__file__": str(root / "tests/_ci_lanes.py")}
exec(subprocess.check_output(["git", "show", f"{pin}:tests/_ci_lanes.py"]), manifest)
profile.LANES = manifest["CI_LANES"]
assert len(profile.LANES) == 19
raw_json = (root / "terminal.json").read_bytes()
raw_log = (root / "terminal.log").read_bytes()
payload = json.loads(raw_json)
assert payload["headSha"] == pin
lines = raw_log.decode("utf-8-sig").splitlines()


def build(document):
    return profile.build_report(document, lines, raw_json, raw_json, raw_log, raw_log, root / "terminal.json", root / "terminal.log")


report = build(payload)
report["source_scope"]["lane_manifest_pin"] = pin
report["source_scope"]["lane_override"] = "CI_LANES from the pinned test router, exact 19-job equality required"
refusals = {}
for label, patch, expected in [
    ("nonterminal", {"status": "in_progress"}, "not terminal"),
    ("failed", {"conclusion": "failure"}, "run failed"),
    ("missing_lane", {"jobs": payload["jobs"][:-1]}, "lane set mismatch"),
]:
    broken = {**payload, **patch}
    refusals[label] = profile.expect_refusal(lambda: build(broken), expected)
broken = copy.deepcopy(payload)
broken["jobs"][0]["conclusion"] = "failure"
refusals["failed_job"] = profile.expect_refusal(lambda: build(broken), "lane did not pass")
report["parent_planted_refusals"] = refusals
(root / "profile.json").write_text(json.dumps(report, indent=2) + "\n")
for lane in report["lanes"]:
    print(lane["lane"], lane["counts"], lane["pytest_seconds"])
print("REFUSALS", refusals)
