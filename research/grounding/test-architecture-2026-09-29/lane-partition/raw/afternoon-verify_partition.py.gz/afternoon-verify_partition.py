import json
import os
import subprocess
import sys
from pathlib import Path

scratch = Path('/tmp/cairn-afternoon-lane3.ADFVbJ')
root = Path(sys.argv[1])
baseline = set()
for name in ('baseline-collection.log', 'baseline-lean-collection.log'):
    baseline.update(line for line in (scratch / name).read_text().splitlines() if line.startswith('tests/') and '::' in line)
assert len(baseline) == 142
counts = {'m0-lineage': 4, 'm0-replay': 2, 'm0-transcript': 3, 'm0-boundaries': 8,
          'lean-core': 121, 'lean-replay': 1, 'solution-library-dlp': 1,
          'solution-library-finite-point': 1, 'solution-library-binding': 1}
populations = {}
combined = set()
env = {**os.environ, 'PYTHONPATH': f'{root}/src:{root}/tests',
       'PYTEST_DEBUG_TEMPROOT': str(scratch / 'pytest-temp')}
env.pop('PYTEST_ADDOPTS', None)
for lane, count in counts.items():
    result = subprocess.run([sys.executable, '-m', 'pytest', '--collect-only', '-q', f'--cairn-ci-lane={lane}'],
                            cwd=root, env=env, capture_output=True, text=True)
    (scratch / f'collection-{lane}.log').write_text(result.stdout + result.stderr)
    assert result.returncode == 0, (lane, result.returncode, result.stdout, result.stderr)
    nodes = [line for line in result.stdout.splitlines() if line.startswith('tests/') and '::' in line]
    assert len(nodes) == len(set(nodes)) == count, (lane, nodes)
    assert not combined.intersection(nodes), lane
    combined.update(nodes)
    populations[lane] = nodes
assert combined == baseline, {'missing': sorted(baseline - combined), 'extra': sorted(combined - baseline)}
(scratch / 'parent-partition.json').write_text(json.dumps(populations, indent=2) + '\n')
print('PASS: all 142 baseline IDs have exactly one leaf owner; counts', counts)
