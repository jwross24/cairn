def pytest_configure(config):
    import _ci_lanes

    _ci_lanes.M0_TEST_CASES['m0-lineage'] = _ci_lanes.M0_TEST_CASES['m0-lineage'][:-1]
