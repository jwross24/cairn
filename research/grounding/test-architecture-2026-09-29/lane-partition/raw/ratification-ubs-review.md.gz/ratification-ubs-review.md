# UBS review for the two ratification fixture modules

Confidence: HIGH for the reported findings. UBS returned exit 1: one critical heuristic, 40 warning entries, and 45 informational entries. This is an adjudicated scan, not a clean scan.

The crypto heuristic points to `TABLE = laddertable.ResultTable(...)`, whose `nonce="nonce-live"` is a deterministic test-table field. It is not an encryption IV or a secret. The table has empty rungs and trials and fixed fixture hashes. No cryptographic primitive consumes this constant as an IV.

Four high-parameter warnings name fixture helpers whose arguments are the real writer, gate bundle, temporary directory, plan, hypothesis, attestation path, and test discriminator. Argument count alone establishes no incorrect behavior.

Thirty JSON warnings are duplicate reports of 15 direct fixture/result parses. A malformed serialized fixture or result must propagate an exception and fail the test. Catching and substituting a value would conceal the failure.

Six missing-context-manager warnings refer to `bundle.GateBundle.open`, a value constructor. Its body reads bundle rows and the pin, verifies their digest, and returns a `GateBundle`; it does not return an open file descriptor. The related informational encoding warnings likewise mistake this method for built-in file open.

The parent read the reported code and `GateBundle.open` and ran both complete affected modules: 39 passed. No suppression or production change accompanies this review.
