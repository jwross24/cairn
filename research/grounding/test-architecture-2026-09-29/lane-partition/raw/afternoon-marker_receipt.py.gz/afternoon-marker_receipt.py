import json
import os
from pathlib import Path


def pytest_collection_finish(session):
    rows = []
    for item in session.items:
        marker = item.get_closest_marker("timeout")
        rows.append({"nodeid": item.nodeid, "timeout": marker.args[0] if marker else float(session.config.getini("timeout"))})
    Path(os.environ["MARKER_RECEIPT"]).write_text(json.dumps(rows, indent=2) + "\n")
